======================================================================
      COBOL QUEST: THE IRON-7090 MAINFRAME CHRONICLES (macOS)
        Supports Apple Silicon (M1/M2/M3/M4) & Intel Macs!
======================================================================

OPTION A — TERMINAL QUICK START (Recommended, Zero Gatekeeper Popup):
----------------------------------------------------------------------
Open Terminal, cd into this extracted folder, and run:

    ./Play-COBOL-Quest.sh

If GnuCOBOL isn't installed yet, it will offer to install it in one
step via Homebrew (brew install gnucobol), compile natively for your
Mac in < 1 second, and launch COBOL QUEST!

OPTION B — DOUBLE-CLICK IN FINDER:
----------------------------------------------------------------------
Double-click:
    Play-COBOL-Quest.command

(Tip: On first launch after downloading from a browser, if macOS
Gatekeeper blocks opening a downloaded script, right-click
Play-COBOL-Quest.command -> Open -> Open, or run in Terminal:
xattr -d com.apple.quarantine Play-COBOL-Quest.command)
======================================================================
