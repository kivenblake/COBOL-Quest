@echo off
setlocal
cd /d "%~dp0"
set "PATH=%~dp0..;%PATH%"
for %%E in (0*.exe) do (
    echo.
    echo ============================================================
    echo  RUNNING %%E
    echo ============================================================
    "%%E"
)
echo.
pause
