======================================================================
   COBOL QUEST: THE IRON-7090 MAINFRAME CHRONICLES (Windows x64)
            100% Written in COBOL (Powered by GnuCOBOL)
======================================================================

HOW TO PLAY IMMEDIATELY (ZERO INSTALLATION REQUIRED!):
----------------------------------------------------------------------
1. Make sure you extracted ALL files from COBOL-Quest-Windows-x64.zip
   into a regular folder (do not run from inside the un-extracted zip).
2. Double-click:
       Play-COBOL-Quest.bat
   (or double-click COBOL-Quest.exe directly!)

TERMINAL COLOR TIP:
----------------------------------------------------------------------
- Windows 11 Terminal and PowerShell render the retro IBM 3270 green
  phosphor colors automatically.
- If you ever see escape characters like <-[1;32m in an older console,
  simply type C and press ENTER on the Main Menu to toggle Clean
  Plain-ASCII Mode!

WHAT'S INCLUDED IN THIS PACKAGE:
----------------------------------------------------------------------
- Play-COBOL-Quest.bat : One-click Windows launcher
- COBOL-Quest.exe      : Precompiled native 64-bit Windows COBOL game!
- src\                 : Full commented COBOL source code of the game!
- examples\            : 8 standalone COBOL programs (.cob + .exe)
                         matching Chapters 1 through 8!
- scripts\             : Optional PowerShell & Batch scripts if you
                         want to install the GnuCOBOL compiler (cobc)
                         locally and compile your own .cob files!
======================================================================
