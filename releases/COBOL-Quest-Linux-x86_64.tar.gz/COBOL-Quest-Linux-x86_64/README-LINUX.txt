======================================================================
   COBOL QUEST: THE IRON-7090 MAINFRAME CHRONICLES (Linux x86_64)
            100% Written in COBOL (Powered by GnuCOBOL)
======================================================================

ZERO-INSTALL QUICK START (No sudo or compiler required!):
----------------------------------------------------------------------
Open a terminal in this extracted folder and run:

    ./Play-COBOL-Quest.sh

(Or run ./cobol-quest directly! Both GnuCOBOL's libcob and GMP are
statically compiled in, so it runs on Ubuntu, Debian, Fedora, Arch,
Linux Mint, Pop!_OS, openSUSE, and WSL out of the box.)

OPTIONAL: EDIT & COMPILE YOUR OWN .COB FILES:
----------------------------------------------------------------------
    ./scripts/install-gnucobol-unix.sh
    make run
======================================================================
