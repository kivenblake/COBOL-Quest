#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for exe in ./0*[!b][!t]; do
  if [ -x "$exe" ]; then
    echo ""
    echo "============================================================"
    echo " RUNNING $(basename "$exe")"
    echo "============================================================"
    "$exe"
  fi
done
